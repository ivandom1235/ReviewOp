# ProtoNet Accuracy Log

## Report Metadata

- Generated: `2026-04-12 23:52` `Asia/Calcutta`
- Source artifacts:
  - `protonet/output/training_history.json`
  - `protonet/output/predictions/test_predictions.jsonl`
- Run command pattern:
  - `python protonet\code\cli.py train --input-type benchmark --input-dir dataset_builder\output\benchmark\ambiguity_grounded`
  - `python protonet\code\cli.py eval --input-type benchmark --input-dir dataset_builder\output\benchmark\ambiguity_grounded --checkpoint protonet\output\checkpoints\best.pt`

## Run Summary

- Previous test accuracy: `74.65%`
- New test accuracy: `75.00%`
- Improvement: `+0.35 percentage points`

## Observed Changes

These are the changes that are visible from the saved outputs for the latest run:

- Validation accuracy decreased from `75.35%` to `74.65%`
- Validation macro F1 decreased from `77.43%` to `76.55%`
- Test accuracy increased from `74.65%` to `75.00%`
- Test macro F1 increased from `72.33%` to `73.06%`
- Aspect-only accuracy increased from `77.43%` to `77.78%`
- Flexible match score increased from `77.43%` to `77.78%`
- Low-confidence rate decreased from `35.42%` to `34.72%`
- Coverage increased from `64.58%` to `65.28%`

## What Likely Changed

I cannot verify the exact code, data, or hyperparameter changes from the saved artifacts alone. Based on the metrics, the most likely improvement came from one or more of the following:

- The quality-aware prototype and loss weighting reduced some noisy support/query influence
- Checkpoint selection shifted toward a slightly better test-oriented model
- The model became less over-conservative, with fewer abstentions
- Confidence calibration improved enough to raise coverage without dropping accuracy

## Notes

- These numbers come from the saved `protonet/output/predictions/test_predictions.jsonl` and `protonet/output/training_history.json` files.
- The log reflects the latest run only and does not modify model behavior.

---

## Latest Run Snapshot

- Timestamp: `2026-04-12 23:52` `Asia/Calcutta`
- Test accuracy: `75.00%`
- Macro F1: `73.06%`
- Aspect-only accuracy: `77.78%`
- Flexible match score: `77.78%`
- Coverage: `65.28%`
- Low-confidence rate: `34.72%`

### Delta vs Previous Saved Run

- Test accuracy: `+0.35 percentage points`
- Macro F1: `+0.73 percentage points`
- Aspect-only accuracy: `+0.35 percentage points`
- Coverage: `+0.69 percentage points`
- Low-confidence rate: `-0.69 percentage points`

### Diagnosis

- Error buckets now show fewer wrong confident predictions than before.
- The biggest remaining confusions are still among `timeliness`, `performance`, `connectivity`, and `service quality`.
- The model is slightly better calibrated, with lower `calibration_ece` and lower abstention rate.
