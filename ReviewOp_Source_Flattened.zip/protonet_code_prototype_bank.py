from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List

import torch

try:
    from .config import ProtonetConfig
    from .quality_signals import example_quality_weight
    from .progress import task_bar
except ImportError:
    from config import ProtonetConfig
    from quality_signals import example_quality_weight
    from progress import task_bar


@dataclass
class PrototypeBank:
    labels: List[str]
    prototypes: torch.Tensor
    counts: Dict[str, int]
    mean_confidence: Dict[str, float]

    def to_serializable(self) -> Dict[str, Any]:
        return {
            "labels": self.labels,
            "prototypes": self.prototypes.detach().cpu(),
            "counts": self.counts,
            "mean_confidence": self.mean_confidence,
        }


def build_global_prototype_bank(model, episodes: List[Dict[str, Any]], cfg: ProtonetConfig) -> PrototypeBank:
    model.eval()
    unique_examples: Dict[str, Dict[str, Any]] = {}
    for episode in episodes:
        for item in list(episode.get("support_set", [])) + list(episode.get("query_set", [])):
            key = str(item.get("example_id") or item.get("parent_review_id"))
            if key not in unique_examples:
                unique_examples[key] = dict(item)

    grouped: Dict[str, List[Dict[str, Any]]] = {}
    for item in unique_examples.values():
        label = str(item.get("joint_label") or f"{item.get('aspect')}{cfg.joint_label_separator}{item.get('sentiment')}")
        grouped.setdefault(label, []).append(item)

    labels = sorted(grouped)
    prototype_rows: List[torch.Tensor] = []
    counts: Dict[str, int] = {}
    mean_confidence: Dict[str, float] = {}
    global_mean = None
    with torch.no_grad():
        embedding_cache: Dict[str, torch.Tensor] = {}
        with task_bar(total=len(labels), desc="prototype-bank", enabled=cfg.progress_enabled) as bar:
            for label in labels:
                items = grouped[label]
                # Memory safety: batch large label clusters during prototype aggregation
                batch_size = 32 if model.encoder.backend == "transformer" else 512
                embeddings_list: List[torch.Tensor] = []
                for i in range(0, len(items), batch_size):
                    batch = items[i : i + batch_size]
                    embeddings_list.append(model.encode_items(batch))
                embeddings = torch.cat(embeddings_list, dim=0)
                
                embedding_cache[label] = embeddings
                raw_confidences = [float(item.get("confidence", 1.0)) for item in items]
                quality_weights = [example_quality_weight(item) for item in items]
                weights = torch.tensor(
                    quality_weights,
                    dtype=torch.float32,
                    device=cfg.device,
                )
                weights = weights / weights.sum().clamp(min=1e-6)
                prototype_rows.append((embeddings * weights.unsqueeze(-1)).sum(dim=0))
                counts[label] = len(grouped[label])
                mean_confidence[label] = round(sum(raw_confidences) / max(1, len(raw_confidences)), 4)
                bar.update(1)
        raw_prototypes = torch.stack(prototype_rows, dim=0)
        global_mean = raw_prototypes.mean(dim=0)
        # Vectorized: interpolate all prototypes toward the global mean in one op
        smoothed = torch.nn.functional.normalize(
            torch.lerp(raw_prototypes, global_mean.unsqueeze(0).expand_as(raw_prototypes), cfg.prototype_smoothing),
            p=2,
            dim=-1,
        )
    return PrototypeBank(labels=labels, prototypes=smoothed, counts=counts, mean_confidence=mean_confidence)
