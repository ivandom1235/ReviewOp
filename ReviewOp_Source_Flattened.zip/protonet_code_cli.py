from __future__ import annotations

import argparse
import os
from pathlib import Path
import sys

try:
    from .config import METADATA_ROOT, OUTPUT_ROOT, ProtonetConfig, env_value, resolve_default_input_dir, seed_everything
    from .dataset_reader import load_input_dataset, write_json, write_jsonl
    from .episode_builder import build_or_load_episode_sets
    from .evaluator import evaluate_episodes
    from .export_bundle import export_model_bundle, export_report
    from .model import ProtoNetModel
    from .trainer import load_checkpoint, train_model
    from .calibrate_novelty import calibrate_thresholds
except ImportError:
    from config import METADATA_ROOT, OUTPUT_ROOT, ProtonetConfig, env_value, resolve_default_input_dir, seed_everything
    from dataset_reader import load_input_dataset, write_json, write_jsonl
    from episode_builder import build_or_load_episode_sets
    from evaluator import evaluate_episodes
    from export_bundle import export_model_bundle, export_report
    from model import ProtoNetModel
    from trainer import load_checkpoint, train_model
    from calibrate_novelty import calibrate_thresholds


def _build_config(args: argparse.Namespace) -> ProtonetConfig:
    input_root = Path(args.input_dir) if args.input_dir else resolve_default_input_dir(args.input_type)
    output_dir = Path(args.output_dir) if args.output_dir else OUTPUT_ROOT
    metadata_dir = Path(args.metadata_dir) if args.metadata_dir else METADATA_ROOT
    return ProtonetConfig(
        input_type=args.input_type,
        input_dir=input_root,
        output_dir=output_dir,
        metadata_dir=metadata_dir,
        checkpoint_dir=output_dir / "checkpoints",
        episode_cache_dir=output_dir / "episodes",
        predictions_dir=output_dir / "predictions",
        encoder_backend=args.encoder_backend,
        encoder_model_name=args.encoder_model_name,
        n_way=args.n_way,
        k_shot=args.k_shot,
        q_query=args.q_query,
        epochs=args.epochs,
        learning_rate=args.learning_rate,
        encoder_learning_rate=args.encoder_learning_rate,
        warmup_epochs=args.warmup_epochs,
        patience=args.patience,
        max_train_episodes=args.max_train_episodes,
        max_eval_episodes=args.max_eval_episodes,
        contrastive_weight=args.contrastive_weight,
        focal_gamma=args.focal_gamma,
        prototype_smoothing=args.prototype_smoothing,
        low_confidence_threshold=args.low_confidence_threshold,
        selective_alpha=args.selective_alpha,
        selective_beta=args.selective_beta,
        selective_gamma=args.selective_gamma,
        selective_delta=args.selective_delta,
        abstain_threshold=args.abstain_threshold,
        multi_label_margin=args.multi_label_margin,
        sentiment_pipeline=args.sentiment_pipeline,
        novelty_threshold=args.novelty_threshold,
        novelty_known_threshold=args.novelty_known_threshold,
        novelty_novel_threshold=args.novelty_novel_threshold,
        ortho_weight=args.ortho_weight,
        novelty_calibration_path=Path(args.novelty_calibration_path) if args.novelty_calibration_path else (metadata_dir / "novelty_calibration_v2.json"),
        seed=args.seed,
        no_progress=args.no_progress,
        force_rebuild_episodes=args.force_rebuild_episodes,
        strict_encoder=args.strict_encoder,
        production_require_transformer=args.production_require_transformer,
        allow_model_download=args.allow_model_download,
        compile_model=args.compile_model,
        train_encoder=args.train_encoder,
    )


def _prepare_examples(cfg: ProtonetConfig):
    rows_by_split, summary = load_input_dataset(cfg)
    return rows_by_split, summary


def namespace_from_payload(command: str, payload: dict[str, object]) -> argparse.Namespace:
    parser = build_parser()
    defaults = parser.parse_args([command])
    for key, value in payload.items():
        setattr(defaults, key, value)
    return defaults


def run_train_local(args: argparse.Namespace) -> dict[str, object]:
    cfg = _build_config(args)
    cfg.ensure_dirs()
    seed_everything(cfg.seed)
    rows_by_split, summary = _prepare_examples(cfg)
    episodes_by_split = build_or_load_episode_sets(rows_by_split, cfg)
    result = train_model(cfg, episodes_by_split)

    # Calibrate using predictions already produced by train_model -- no extra eval pass needed.
    if cfg.save_predictions:
        novelty_calibration = calibrate_thresholds(result.val_predictions)
        cfg.novelty_known_threshold = float(novelty_calibration.get("thresholds", {}).get("T_known", cfg.novelty_known_threshold))
        cfg.novelty_novel_threshold = float(novelty_calibration.get("thresholds", {}).get("T_novel", cfg.novelty_novel_threshold))
        write_json(cfg.novelty_calibration_path, novelty_calibration)
        val_metrics = result.val_metrics
        test_metrics = result.test_metrics
        write_jsonl(cfg.predictions_dir / "val_predictions.jsonl", result.val_predictions)
        write_jsonl(cfg.predictions_dir / "test_predictions.jsonl", result.test_predictions)
    else:
        val_metrics = result.val_metrics
        test_metrics = result.test_metrics
        novelty_calibration = {}

    bundle_path = export_model_bundle(
        cfg=cfg,
        model=result.model,
        prototype_bank=result.prototype_bank,
        checkpoint_path=result.checkpoint_path,
        metrics={"val": val_metrics, "test": test_metrics},
        history=result.history,
        novelty_calibration=novelty_calibration,
    )
    report_path = export_report(
        cfg=cfg,
        input_summary={
            "split_sizes": summary.split_sizes,
            "detected_format": summary.detected_format,
            "input_type": summary.input_type,
            "episode_counts": {split: len(rows) for split, rows in episodes_by_split.items()},
        },
        train_metrics=result.history[-1] if result.history else {},
        val_metrics=val_metrics,
        test_metrics=test_metrics,
        bundle_path=bundle_path,
        checkpoint_path=result.checkpoint_path,
        history=result.history,
        novelty_calibration=novelty_calibration,
    )
    return {"report_path": str(report_path), "bundle_path": str(bundle_path), "checkpoint_path": str(result.checkpoint_path)}


def run_eval_local(args: argparse.Namespace) -> dict[str, object]:
    cfg = _build_config(args)
    cfg.ensure_dirs()
    seed_everything(cfg.seed)
    rows_by_split, _ = _prepare_examples(cfg)
    episodes_by_split = build_or_load_episode_sets(rows_by_split, cfg)
    model = ProtoNetModel(cfg)
    checkpoint_path = Path(args.checkpoint) if args.checkpoint else cfg.checkpoint_dir / "best.pt"
    load_checkpoint(model, checkpoint_path)
    split = args.split
    metrics, predictions = evaluate_episodes(model, episodes_by_split[split], cfg, split)
    write_jsonl(cfg.predictions_dir / f"{split}_predictions.jsonl", predictions)
    return {"metrics": metrics, "prediction_count": len(predictions), "checkpoint_path": str(checkpoint_path)}


def run_train(args: argparse.Namespace) -> int:
    payload = run_train_local(args)
    report_path = payload.get("report_path", "<unknown>")
    print(f"Training complete. Report: {report_path}")
    return 0


def run_eval(args: argparse.Namespace) -> int:
    payload = run_eval_local(args)
    print(payload.get("metrics", payload))
    return 0


def run_export(args: argparse.Namespace) -> int:
    cfg = _build_config(args)
    cfg.ensure_dirs()
    seed_everything(cfg.seed)
    rows_by_split, _ = _prepare_examples(cfg)
    episodes_by_split = build_or_load_episode_sets(rows_by_split, cfg)
    model = ProtoNetModel(cfg)
    checkpoint_path = Path(args.checkpoint) if args.checkpoint else cfg.checkpoint_dir / "best.pt"
    load_checkpoint(model, checkpoint_path)
    try:
        from .prototype_bank import build_global_prototype_bank
    except ImportError:
        from prototype_bank import build_global_prototype_bank

    bank = build_global_prototype_bank(model, episodes_by_split["train"], cfg)
    bundle_path = export_model_bundle(
        cfg=cfg,
        model=model,
        prototype_bank=bank,
        checkpoint_path=checkpoint_path,
        metrics={},
        history=[],
    )
    print(f"Exported bundle: {bundle_path}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Standalone ProtoNet training pipeline")
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--input-type", choices=["benchmark"], default="benchmark")
    common.add_argument("--input-dir", type=str, default=None)
    common.add_argument("--output-dir", type=str, default=None)
    common.add_argument("--metadata-dir", type=str, default=None)
    common.add_argument("--encoder-backend", choices=["auto", "transformer", "bow"], default="auto")
    common.add_argument("--encoder-model-name", type=str, default=env_value("REVIEWOP_PROTONET_ENCODER_MODEL", "PROTONET_ENCODER_MODEL", default="microsoft/deberta-v3-base") or "microsoft/deberta-v3-base")
    common.add_argument("--n-way", type=int, default=3)
    common.add_argument("--k-shot", type=int, default=2)
    common.add_argument("--q-query", type=int, default=2)
    common.add_argument("--epochs", type=int, default=12)
    common.add_argument("--learning-rate", type=float, default=6e-4)
    common.add_argument("--encoder-learning-rate", type=float, default=1.2e-5)
    common.add_argument("--warmup-epochs", type=int, default=1)
    common.add_argument("--patience", type=int, default=4)
    common.add_argument("--max-train-episodes", type=int, default=120)
    common.add_argument("--max-eval-episodes", type=int, default=48)
    common.add_argument("--contrastive-weight", type=float, default=0.22)
    common.add_argument("--focal-gamma", type=float, default=1.8)
    common.add_argument("--prototype-smoothing", type=float, default=0.08)
    common.add_argument("--low-confidence-threshold", type=float, default=0.25)
    common.add_argument("--selective-alpha", type=float, default=1.0)
    common.add_argument("--selective-beta", type=float, default=0.0)
    common.add_argument("--selective-gamma", type=float, default=0.0)
    common.add_argument("--selective-delta", type=float, default=0.0)
    common.add_argument("--abstain-threshold", type=float, default=0.01)
    common.add_argument("--multi-label-margin", type=float, default=0.10)
    common.add_argument("--sentiment-pipeline", type=str, default="both", choices=["joint", "post_aspect", "both"])
    common.add_argument("--novelty-threshold", type=float, default=0.70)
    common.add_argument("--novelty-known-threshold", type=float, default=0.50)
    common.add_argument("--novelty-novel-threshold", type=float, default=0.80)
    common.add_argument("--novelty-calibration-path", type=str, default=None)
    common.add_argument("--seed", type=int, default=42)
    common.add_argument("--no-progress", action="store_true")
    common.add_argument("--force-rebuild-episodes", action="store_true")
    common.add_argument("--strict-encoder", action="store_true")
    common.add_argument("--production-require-transformer", action="store_true")
    common.add_argument("--allow-model-download", action="store_true")
    common.add_argument("--compile-model", action="store_true")
    common.add_argument("--no-train-encoder", action="store_false", dest="train_encoder", default=True)
    common.add_argument("--ortho-weight", type=float, default=0.05)

    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("train", help="Train, validate, test, and export", parents=[common])

    eval_parser = subparsers.add_parser("eval", help="Evaluate a trained checkpoint", parents=[common])
    eval_parser.add_argument("--split", choices=["train", "val", "test"], default="test")
    eval_parser.add_argument("--checkpoint", type=str, default=None)

    export_parser = subparsers.add_parser("export", help="Export a portable bundle from a checkpoint", parents=[common])
    export_parser.add_argument("--checkpoint", type=str, default=None)
    return parser


def _normalize_argv(argv: list[str] | None) -> list[str] | None:
    if argv is None:
        return None
    commands = {"train", "eval", "export"}
    for index, token in enumerate(argv):
        if token in commands:
            if index == 0:
                return argv
            return [token, *argv[:index], *argv[index + 1 :]]
    return argv


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(_normalize_argv(argv))
    if args.command == "train":
        return run_train(args)
    if args.command == "eval":
        return run_eval(args)
    if args.command == "export":
        return run_export(args)
    parser.error(f"Unknown command: {args.command}")
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
